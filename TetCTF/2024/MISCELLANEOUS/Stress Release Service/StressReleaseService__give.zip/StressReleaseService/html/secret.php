<?php 

// Veryyyyyy Secretttttttttttt !!!!!!!!!!!!!!!!!
$FL4ggggggggggg = "TetCTF{Fake_FLAG}";

?>