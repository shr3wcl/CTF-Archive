#!/bin/sh

#echo "start"
/home/interface/interface /home/interface/backend
