#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("FLAG: TetCTF{flag_cc}\n");
}